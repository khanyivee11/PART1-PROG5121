/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.registerandlogin;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Scanner;

public class RegisterAndLogin {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Login> users = new ArrayList<>(); // store a number of users

        System.out.println("\nWelcome to our chat app 2026! Select options below");

        while (true) {
            // Display menu after each action
            System.out.println("\nMenu");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.println("Choose an option:");

            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {

                case 1: // Registration
                    System.out.println("Enter username:");
                    String username = scanner.nextLine();
                    System.out.println("Username successfully captured");

                    // Validation of username: must contain underscore and be at least 5 chars
                    boolean validUsername = username.contains("_") && username.length() >= 5;
                    if (!validUsername) {
                        System.out.println("Username must contain at least one underscore and be at least 5 characters long.");
                        break;
                    }

                    System.out.println("Enter password:");
                    String password = scanner.nextLine();
                    System.out.println("Password successfully captured!");

                    // Validation of password: 8+ chars, one uppercase, one digit, one special char
                    boolean validPassword = password.length() > 8
                            && password.matches(".*[A-Z].*")
                            && password.matches(".*\\d.*")
                            && password.matches(".*[^a-zA-Z0-9].*");
                    if (!validPassword) {
                        System.out.println("Password must be at least 8 characters long, contain an uppercase letter, a number, and a special character.");
                        break;
                    }

                    System.out.print("Enter a SA phone number (e.g. +27831111111): ");
                    String phoneNumber = scanner.nextLine();
                    System.out.println("Cellphone number successfully added!");

                    // Validate phone number: +27 followed by 9 digits
                    String regex = "\\+27[0-9]{9}";
                    if (!phoneNumber.matches(regex)) {
                        System.out.println("Invalid phone number format. Use +27xxxxxxxxx");
                        break;
                    }

                    // Check if the user already exists
                    boolean userExists = users.stream().anyMatch(u -> u.getUsername().equals(username));
                    if (userExists) {
                        System.out.println("Username already exists. Please choose another username.");
                        break;
                    }

                    // Add the new user
                    users.add(new Login(username, password, phoneNumber));
                    System.out.println("User registered successfully!");

                    // Welcome the user and transition to login
                    System.out.println("Welcome " + username + "! You can now log in.");
                    System.out.println("Redirecting you to the login page.......\n");

                    // Immediately prompt the user to login
                    promptLogin(scanner, users);
                    break;

                case 2: // Login
                    if (users.isEmpty()) {
                        System.out.println("No users are registered yet. Please register first.");
                        break;
                    }
                    // Prompt the user to login
                    promptLogin(scanner, users);
                    break;

                case 3: // Exit
                    System.out.println("Goodbye!");
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid option. Please choose 1, 2, or 3.");
            }
        }
    }

    // Method to handle Login Logic
    private static void promptLogin(Scanner scanner, ArrayList<Login> users) {
        System.out.print("Enter username: ");
        String enteredUsername = scanner.nextLine();
        System.out.print("Enter password: ");
        String enteredPassword = scanner.nextLine();

        // Find user and attempt login
        Login user = users.stream()
                .filter(u -> u.getUsername().equals(enteredUsername))
                .findFirst()
                .orElse(null);

        boolean loginStatus = user != null && user.loginUser(enteredPassword);
        System.out.println(user != null ? user.returnLoginStatus(loginStatus) : "User not found.");
    }
}

// Login class
class Login {
    private String username;
    private String passwordHash;
    private String phoneNumber;
    private byte[] salt;

    public Login(String username, String password, String phoneNumber) {
        this.username = username;
        this.salt = generateSalt();
        this.passwordHash = hashPassword(password, salt);
        this.phoneNumber = phoneNumber;
    }

    public String getUsername() {
        return username;
    }

    public boolean loginUser(String enteredPassword) {
        return this.passwordHash.equals(hashPassword(enteredPassword, salt));
    }

    public String returnLoginStatus(boolean status) {
        if (status) {
            return "Login successful! Welcome back, " + username + "!";
        } else {
            return "Login failed. Incorrect password.";
        }
    }

    // Hash password with salt using SHA-256
    private String hashPassword(String password, byte[] salt) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(salt); // add salt to the hash
            byte[] hash = md.digest(password.getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                hexString.append(String.format("%02x", b));
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Error hashing password", e);
        }
    }

    // Generate a random salt for password hashing
    private byte[] generateSalt() {
        try {
            SecureRandom random = new SecureRandom();
            byte[] salt = new byte[16];
            random.nextBytes(salt);
            return salt;
        } catch (Exception e) {
            throw new RuntimeException("Error generating salt", e);
        }
    }
}